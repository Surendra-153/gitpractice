package com.first;

public interface TestInterface {

	
	public void add();
}
