
public class PrimeNumbers {

	public static void main(String[] args) {
		
	

	}

}
