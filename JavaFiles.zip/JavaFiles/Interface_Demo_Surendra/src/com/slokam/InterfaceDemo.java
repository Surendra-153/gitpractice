package com.slokam;

public interface InterfaceDemo {
	
	public  void getMethod() ;//unimpl
	
	public static void fuckSaiRaj() {
		System.out.println("SiaRaj Method in interface");
	};
	
	

}
