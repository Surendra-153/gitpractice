package com.slokam;

public class InterfaceImpl2 {

}
