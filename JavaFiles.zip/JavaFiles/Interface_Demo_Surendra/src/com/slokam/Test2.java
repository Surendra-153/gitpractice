package com.slokam;

public class Test2{
	
	public static InterfaceDemo objTwo() {
		InterfaceDemo.fuckSaiRaj();
		return null;
		
		
	}
	public static void main(String[] args) {
		Test2.objTwo();
	}
}
