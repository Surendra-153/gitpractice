package com.slokam;

public class InterfaceImpl1 {
	
	

}
