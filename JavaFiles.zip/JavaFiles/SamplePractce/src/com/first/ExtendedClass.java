package com.first;

public class ExtendedClass implements Inteface1{

	@Override
	public void m1() {
		System.out.println("Hi m1 method");
		
	}
	public static void main(String[] args) {

		
		
	}


}
