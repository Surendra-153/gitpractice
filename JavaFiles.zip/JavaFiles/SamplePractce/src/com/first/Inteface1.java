package com.first;

public interface Inteface1 {
	abstract void m1();
	
}
