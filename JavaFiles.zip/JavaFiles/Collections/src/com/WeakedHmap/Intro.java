package com.WeakedHmap;

import java.util.*;


public class Intro {
	private String sName;
	
	public String getsName() {
	return sName;
}

public void setsName(String sName) {
	this.sName = sName;
}



public Intro(String sName) {
	super();
	this.sName = sName;
}

public static void main(String[] args) {
	String d ="sai";
	String d1 ="Siva";
	



	}
}
