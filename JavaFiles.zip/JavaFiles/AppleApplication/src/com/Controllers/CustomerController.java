package com.Controllers;

import com.pojo.CustomerPojo;

public class CustomerController {

	
	public String raiseBug(CustomerPojo customer) {
	
		String cbug = null;
		return cbug;
	}
}
