package com.ClassExample;

public class Car {
	
	String Color;
	int EngineCC;
	String FuelType;
	int SafetyBags=5;
}
