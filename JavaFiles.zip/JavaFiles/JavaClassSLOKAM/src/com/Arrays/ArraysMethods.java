package com.Arrays;



public class ArraysMethods {
	public static void main(String[] args) {
		
	}
}
