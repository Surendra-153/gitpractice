package com.Arrays;

public class ArraysIntro {
	public static void main(String[] args) {
		int Price[]= {10,20,30,40};//Initialization
		int arr[] = new int[6];//Declaration
		arr[0]=31;//initialization
		arr[1]=32;
		arr[2]=33;
		arr[3]=34;
		arr[4]=35;
		arr[5]=36;
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);
		System.out.println(arr[5]);
		
		System.out.println("---------------------");
		System.out.println(Price[0]);
		
		
	}
}
