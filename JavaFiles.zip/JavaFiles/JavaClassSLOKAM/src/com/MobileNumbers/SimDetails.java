package com.MobileNumbers;

public class SimDetails {
	private long SimNumber;
	private String SimComp;
	private String SimState;
	
	
	
	public long getSimNumber() {
		return SimNumber;
	}
	public void setSimNumber(long simNumber) {
		SimNumber = simNumber;
	}
	public String getSimComp() {
		return SimComp;
	}
	public void setSimComp(String simComp) {
		SimComp = simComp;
	}
	public String getSimState() {
		return SimState;
	}
	public void setSimState(String simState) {
		SimState = simState;
	}
	
	
}
