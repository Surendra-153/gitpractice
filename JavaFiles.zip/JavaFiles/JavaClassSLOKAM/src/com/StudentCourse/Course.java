package com.StudentCourse;

public class Course {
	private int Cid;
	private String Cname;
	private double Cfee;
	
	
	public int getCid() {
		return Cid;
	}
	public void setCid(int cid) {
		Cid = cid;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public double getCfee() {
		return Cfee;
	}
	public void setCfee(double cfee) {
		Cfee = cfee;
	}
	
}
