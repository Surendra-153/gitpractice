
public class BinaryConversion{
	public static void main(String[] args) {
	int num=2;
	while(num>0) {
		System.out.print(num%2+" ");
		num=num/2;
	}
 }
}