
public class FirstPractice {
	public static void main(String[] args) {
	int num=123456789;
	while(num>0) {
		System.out.print(num%10+" ");
		num=num/10;
		
	}
 }
}