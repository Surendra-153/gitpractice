package TypeCasting;

public class Test1 {
		int age; // Instance Variable
		String name;
		
		
	public static void main(String[] args) {
		
		//int exp ;// Local Variable has to be initialized before it is called...
		
		Test1 t= new Test1();
		t.age=20;
		System.out.println(t.age);
		String comp="SDB";//Local Variable
		System.out.println("---");	
		System.out.println(comp);
	}

}
