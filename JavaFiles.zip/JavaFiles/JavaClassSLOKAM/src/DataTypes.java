
public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Two types of data types;
		//Primitive and non primitive
		//======Primitive===========
		byte age=30;
		short Salary=10000;
		int worth=500000;
		long net=79875895898058584l;
		
		float height=5.70f;
		double weight=67.897;
		
		char Gender ='M';
		boolean MS=false;
		
		
		
		//===========Non Primitive=======
		//Arrays,String etc...
		String name ="Shiva";
		/////======Primitive==============
		System.out.println("Name : "+name);
		System.out.println("Age : "+age);
		System.out.println("Salary : "+Salary);
		System.out.println("Worth : "+worth);
		System.out.println("Net : "+net);
		System.out.println("Height : "+height);
		System.out.println("Weight : "+weight);
		System.out.println("Gender : "+Gender);
		System.out.println("Martial Status : "+MS);
		
	}

}
