
public class Swapping {
public static void main(String[] args) {
	int a=10;
	int b=15;
	b=a+b;//b=25
	a=b-a;//a=25-10=15
	b=b-a;//b=25-15=10
	System.out.println(a);
	System.out.println(b);
	
}
}
