package Covariant;

public class B extends A{
//child -subclass
	public Integer m1() {
		System.out.println("child -subclass ----m1");
		return null;
	}
}
