package Covariant;

public abstract class A {
	//SuperClass
	public Object m1() {
		System.out.println("SuperClass M1");
		return null;
	}
}
