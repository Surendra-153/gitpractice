package Covariant;

public class Display {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b =new B();
		b.m1();
		A b1 =new B();//her ref is A and obj is of B 
		b1.m1();
		

}
}
