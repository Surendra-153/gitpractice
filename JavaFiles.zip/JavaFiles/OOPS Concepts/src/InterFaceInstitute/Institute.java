package InterFaceInstitute;

public interface Institute {
	public abstract void course();
	public abstract void fee();
	
}
