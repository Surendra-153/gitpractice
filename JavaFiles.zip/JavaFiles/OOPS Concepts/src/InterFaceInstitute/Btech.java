package InterFaceInstitute;

public class Btech implements Institute{
	public void course() {
		System.out.println("Btech");		
	}

	
	public void fee() {
		// TODO Auto-generated method stub
		System.out.println(70000);
		
	}
}
