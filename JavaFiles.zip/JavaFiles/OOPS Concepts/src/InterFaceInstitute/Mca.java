package InterFaceInstitute;

public class Mca implements Institute {

	
	public void course() {
		System.out.println("Mca");		
	}

	
	public void fee() {
		// TODO Auto-generated method stub
		System.out.println(42000);
		
	}

}
