package InterFaceInstitute;

public class Bsc implements Institute{
	public void course() {
		System.out.println("Bsc");		
	}

	
	public void fee() {
		// TODO Auto-generated method stub
		System.out.println(30000);
		
	}
}
