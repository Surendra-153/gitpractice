package MultipleInheritence;

public interface B {

	
	int cons =30;
	
	public void add();
	public void b();
}
