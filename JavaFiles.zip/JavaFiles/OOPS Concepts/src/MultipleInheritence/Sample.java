package MultipleInheritence;
 import  OverRiding.SampleProtected;
public class Sample extends SampleProtected {

	public static void main(String[] args) {
		
		Sample s =new Sample();
		s.sample();
	}

}
