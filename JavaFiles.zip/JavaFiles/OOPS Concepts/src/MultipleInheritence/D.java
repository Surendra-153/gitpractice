package MultipleInheritence;

public interface D extends A {
	
	
	
	public void d();

}
