package MultipleInheritence;

public interface A {
 
	
	int cons=20;
	
	public void add();
	public void a();
}
