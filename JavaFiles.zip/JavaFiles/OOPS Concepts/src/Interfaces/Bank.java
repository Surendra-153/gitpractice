package Interfaces;

public  interface Bank {
// this must be consist of only abstract methods
	
	public abstract void docs();
	public abstract void ROI();
	public static void m1() {
		System.out.println("hi");
	}
}
