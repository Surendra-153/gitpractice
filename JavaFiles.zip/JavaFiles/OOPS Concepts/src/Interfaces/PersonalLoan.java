package Interfaces;

public class PersonalLoan implements Bank {

	
	public void docs() {
		System.out.println("Payslips and other Documents");
	}
	public void ROI() {
		System.out.println("ROI--->11.5");
	}

}
