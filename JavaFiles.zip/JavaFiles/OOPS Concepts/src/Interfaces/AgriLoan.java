package Interfaces;

public class AgriLoan implements Bank {
	//here the abstract method are implemented by implementing 
	public void docs() {
		System.out.println("Land Documents");
	}
	public void ROI() {
		System.out.println("ROI--->3.5");
	}
	public void Field() {
		System.out.println("Agriculture");
	}

}
