package Interfaces;


/**NOTES**

 * We cannot create the objects for the interfaces 
 * it is because THE JVM doesn't know the Space to be given for
 * ...unimplemented methods
 * only unimplemented methods are allowed
 * ---------------------------------------------------------------
 * Interface can only consists of abstract methods
 * Interface is nothing but the specifications or unimplemented methods
 * 
 * 
 */