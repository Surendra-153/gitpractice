package Interfaces;

public class EduLoan implements Bank {
	public void docs() {
		System.out.println("Education Documents");
	}
	public void ROI() {
		System.out.println("ROI--->8.5");
	}
	public void Field() {
		System.out.println("Education");
	}

}
