package com.InterfaceExample;

/**KEY POINTS
 * In interface , the variables are static ,final by default
 * methods are Abstract
 */
