package com.InterfaceExample;

public interface Bank {
	
	public abstract double rateOfInt(double amount) ;

}
