package com.InterfaceExample;

public class Icici implements Bank {

	
	public static double roi =12;
	public double rateOfInt(double amount) {
		// TODO Auto-generated method stub
		return (amount/100)*roi;
	}

}
