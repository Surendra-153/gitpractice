package InheritenceTwo;

public class SuperClass {
	public void gold() {
		System.out.println("this method is gold in Parent Class");
	}
	public void house() {
		System.out.println("this method is House in Parent(Super) Class");
	}
}
