package InheritenceTwo;

public class SubClass extends SuperClass {
	public void bike() {
		System.out.println("this method is bike in Child Class");
	}
	
	public void Loan() {
		System.out.println("this method is Loan in Child Class");
	}
	public void house() {
		System.out.println("this method is House in child(subclass) Class");
	}
}
