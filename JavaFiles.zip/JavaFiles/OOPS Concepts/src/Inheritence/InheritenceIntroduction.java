package Inheritence;



public class InheritenceIntroduction {
	public static void main(String[] args) {
		Child c = new Child();
		c.bike();
		c.Loan();
		c.gold();//this is parent class method that is inherited from parent class
		c.house();//this is parent class method that is inherited from parent class
	}
}
