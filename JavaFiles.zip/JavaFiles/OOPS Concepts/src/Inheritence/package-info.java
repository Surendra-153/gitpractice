package Inheritence;

/**NOTES**

 * Using Key word "extends" we inherit the classes
 * Parent Class - Super Class.
 * Child Class - subClass(This will extends Super Class) 
 * If two same methods are present in the child and parent class...
 * ...The Child method is called and ignores parent method
 * this improves the code re usability
 * 

 *  */
