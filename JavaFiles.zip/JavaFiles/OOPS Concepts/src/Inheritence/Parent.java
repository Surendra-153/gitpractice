package Inheritence;

public class Parent {
	public void gold() {
		System.out.println("this method is gold in Parent Class");
	}
	public void house() {
		System.out.println("this method is House in Parent Class");
	}
}
