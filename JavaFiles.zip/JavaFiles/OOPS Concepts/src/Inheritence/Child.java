package Inheritence;

public class Child extends Parent {
	public void bike() {
		System.out.println("this method is bike in Child Class");
	}
	
	public void Loan() {
		System.out.println("this method is Loan in Child Class");
	}
}
