package InterFaceExample2;

public class Sreech extends Fee {

	public double Cfee(double fee) {
		// TODO Auto-generated method stub
		return 80000;
	}
	
}
