package InterFaceExample2;

public class SR extends Fee {
	public double Cfee(double fee) {
		// TODO Auto-generated method stub
		return fee;
	}
}
