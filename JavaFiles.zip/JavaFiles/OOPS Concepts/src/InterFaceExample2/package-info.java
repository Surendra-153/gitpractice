package InterFaceExample2;
/*
 * we cannot create objects for Abstract Classes 
 * in order to create we must inherit them
 */