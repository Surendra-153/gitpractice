package MultiLeveLInheritence;

public class GrandParent {
	
	public void house() {
		System.out.println("this method is House in Grand Parent Class");
	}
	public void Land() {
		System.out.println("this method is Land in Grand Parent Class");
	}

}
