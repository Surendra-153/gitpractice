package MultiLeveLInheritence;

public class Parent extends GrandParent {

	public void house() {
		System.out.println("this method is House in Parent Class");
	}
	public void gold() {
		System.out.println("this method is gold in Parent Class");
	}
	public void car() {
		System.out.println("this method is car in Parent Class");
	}
}
