package OverRiding;

import MultipleInheritence.Sample;

public class SampleProtected{

	 protected void sample() {
		System.out.println("Sample Protected Method");
	}

}
