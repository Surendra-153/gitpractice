package AddMethod;
import java.util.*;
public class Test {
public static void main(String[] args) {
	HashSet hs = new HashSet();
	hs.add(12);
	hs.add("Sai");
	


System.out.println(hs);}
}
