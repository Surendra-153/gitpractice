package com.srddao;

import com.stdpojo.stdpojo;

public class stddao {
	
	public void save(stdpojo p) {
		System.out.println("-------Student DAO started----------");
		System.out.println(p);
		System.out.println("-------Student DAO Ended----------");
	}
}
