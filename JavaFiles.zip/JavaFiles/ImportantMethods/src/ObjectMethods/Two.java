package ObjectMethods;

public class Two {
	private int age;
	private String name;
	
	public Two(int age,String name) {
		this.age =age;
		this.name =name;
	}
	
}
