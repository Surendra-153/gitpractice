package ObjectMethods;

public class Three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Two d = new Two(12, "Sai");
		

	}

}
