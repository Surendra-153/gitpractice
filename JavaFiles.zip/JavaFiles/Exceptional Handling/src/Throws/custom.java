package Throws;

public class custom {

}
