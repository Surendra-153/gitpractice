package Throws;
// Overiding exceptions:
//can have a same exception in child and parent class
//can have no exception  in child class
//but no parent in child and child in parent class
// can have 
public class Parent {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
