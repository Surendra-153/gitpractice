package Throws;

public class Child {
	
}
