package CompileTimeException;

public class One {

}
