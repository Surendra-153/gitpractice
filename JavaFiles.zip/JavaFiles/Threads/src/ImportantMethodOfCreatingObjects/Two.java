package ImportantMethodOfCreatingObjects;

public abstract class Two {

	public abstract void m2();
	public void m3() {
		System.out.println("M3 method in abstract Two");
	}

}
