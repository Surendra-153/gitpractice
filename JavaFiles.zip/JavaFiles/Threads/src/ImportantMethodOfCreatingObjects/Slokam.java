package ImportantMethodOfCreatingObjects;

public interface Slokam {
	public void m1();
	
}
