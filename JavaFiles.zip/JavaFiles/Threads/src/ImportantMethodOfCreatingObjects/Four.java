package ImportantMethodOfCreatingObjects;

public class Four {
	public void m5() {
		System.out.println("M5 method in Normal Class");
	}
}
